package appiumDemo;

import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;


import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;

import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.PointOption.point;


@Test
public class Case2ViewControls extends BaseSet {
	public void ViewControls() throws MalformedURLException, InterruptedException {
	
		Screen_Page page=new Screen_Page();
		TouchAction touch=new TouchAction(BaseSet.driver);
		
		
//List<MobileElement> listElement=(List<MobileElement>)driver.findElementsById("android:id/text1");

//---------------------------------------Clicking Views Option-----------------------------------------
		
		touch.tap(tapOptions().withElement(element(page.listElement.get(11)))).perform();
      //driver.resetInputState()
	  //touch.release();
		
//---------------------------------------Clicking Controls Option------------------------------------	
		
				
         touch.tap(tapOptions().withElement(element(page.listElement.get(4)))).perform();

//----------------------------------------Clicking on Hold Or Old Theme--------------------
		  
//	    List<MobileElement> listElement2 = (List<MobileElement>)driver.findElementsById("io.appium.android.apis:id/chronometer");
         
         touch.tap(tapOptions().withElement(element(page.listElement.get(5)))).perform();
	    		

	    
////-------------------------------Selecting Radio Button and Check Box-------------------------------
     page.checkbox1Click.click();
    //Selecting the first checkbox
   	System.out.println("First Checkbox is selected");
   	      
   	page.checkbox2Click.click();
    //Selecting the second checkbox
    System.out.println("Second Checkbox is selected");
			
    page.radio1Click.click();
  //Selecting the first radio
   	System.out.println("First RadioButton is selected");
   	
   	page.radio2Click.click();
    //Selecting the second radio
     System.out.println("Second RadioButton is selected");

	}
}
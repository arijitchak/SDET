package appiumDemo;

import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;

import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.PointOption.point;


@Test
public class Case1ViewChronometerValidation extends BaseSet {
	public void ViewChronometerValidation() throws MalformedURLException, InterruptedException {
	
		Screen_Page page=new Screen_Page();
		TouchAction touch=new TouchAction(BaseSet.driver);
		
//List<MobileElement> listElement=(List<MobileElement>)driver.findElementsById("android:id/text1");

//---------------------------------------Clicking Views Option-----------------------------------------
		
		touch.tap(tapOptions().withElement(element(page.listElement.get(11)))).perform();
      //driver.resetInputState()
	  //touch.release();
		
//---------------------------------------Clicking Chronometer Option------------------------------------	
		
				
         touch.tap(tapOptions().withElement(element(page.listElement.get(3)))).perform();

//----------------------------------------Reading Initial Format 00:00--------------------
		  
//	    List<MobileElement> listElement2 = (List<MobileElement>)driver.findElementsById("io.appium.android.apis:id/chronometer"); 
	    		
	    System.out.println("Initial Time reset to Zero"+page.listElement1.get(0).getText());
	    
//-------------------------------Clicking on Start Button and Printing Time-------------------------------
//	    List<MobileElement> listElement3 = (List<MobileElement>)driver.findElementsById("io.appium.android.apis:id/start");
	    
        touch.press(element(page.listElement2.get(0))).release().perform();
	    Thread.sleep(1000);
	    	    
	    System.out.println("Time after clicking Start"+page.listElement1.get(0).getText());	
	    Thread.sleep(10000);
			
//--------------------------------Clicking on Stop Button and Printing Time--------------------------------
//	    List<MobileElement> listElement4 = (List<MobileElement>)driver.findElementsById("io.appium.android.apis:id/stop");
	     
	    touch.press(element(page.listElement3.get(0))).release().perform();
	    	    	    
	    System.out.println("Time after clicking Stop"+page.listElement1.get(0).getText());	

//--------------------------------Clicking on Reset Button and Printing Time--------------------------------
//	    List<MobileElement> listElement4 = (List<MobileElement>)driver.findElementsById("io.appium.android.apis:id/stop");
	     
	    touch.press(element(page.listElement4.get(0))).release().perform();
	    	    	    
	    System.out.println("Time after clicking reset"+page.listElement1.get(0).getText());	
	    
       

	}
}
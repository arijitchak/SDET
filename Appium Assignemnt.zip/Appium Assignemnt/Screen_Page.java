package appiumDemo;

import java.util.List;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class Screen_Page extends BaseSet

{

	@FindBy(id = "android:id/text1")
	public List<MobileElement> listElement;

	@FindBy(id = "io.appium.android.apis:id/chronometer")
	public List<MobileElement> listElement1;

	@FindBy(id = "io.appium.android.apis:id/start")
	public List<MobileElement> listElement2;

	@FindBy(id = "io.appium.android.apis:id/stop")
	public List<MobileElement> listElement3;
	
	@FindBy(id = "io.appium.android.apis:id/reset")
	public List<MobileElement> listElement4;
	
		
	@FindBy(id="io.appium.android.apis:id/check1")
	public MobileElement checkbox1Click;
	
	@FindBy(id="io.appium.android.apis:id/check2")
	public MobileElement checkbox2Click;
	
	@FindBy(id="io.appium.android.apis:id/radio1")
	public MobileElement radio1Click;
	
	@FindBy(id="io.appium.android.apis:id/radio2")
	public MobileElement radio2Click;
	
	public Screen_Page() {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

}

package Day4;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import java.awt.AWTException;


public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
    	//launching Chrome
//    	System.setProperty("webdriver.chrome.driver","C:\\Users\\03800E744\\eclipse-workspace\\Reskill\\chromedriver.exe");
//    	WebDriver wd=new ChromeDriver();
		//Navigating to google
//		wd.get("https://www.google.com/");
//    	Thread.sleep(5000);
//		System.out.println("Success");
//		wd.manage().window().maximize();
//		Thread.sleep(5000);
		//Extracting Navigated URL
//		System.out.println(wd.getCurrentUrl());
		//Extracting Title
//		System.out.println("TITLE:"+ wd.getTitle());
		//Closing Chrome
		//wd.close();
		//wd.navigate().to("http://yahoo.com/");
		//wd.navigate().back();
		//wd.navigate().refresh();
		//wd.findElement(By.name("q")).sendKeys("seleinum"+Keys.ENTER);
		//wd.findElement(By.className("gNO89b")).click();
		
//Iterating through all the links displayed in a web page--XPATH
		
//		List<WebElement>  listLinks=wd.findElements(By.xpath("//a/h3"));
//		for(int i=0;i<listLinks.size();i++) {
//			System.out.println(listLinks.get(i).getText());
//			listLinks.get(i).getAttribute("class")
//		}
//        for(WebElement eachElement:listLinks) {
//			System.out.println(eachElement.getText());
//			listLinks.get(i).getAttribute("class")
		
//Radio Button click----Iterating through all the links displayed in a web page--XPATH
			
//        wd.get("https://demos.jquerymobile.com/1.4.5/checkboxradio-radio/");
//        List<WebElement> 
//        listLinks=wd.findElements(By.xpath("//label[text()='Two']"));
//        for(WebElement eachElement:listLinks) 
//        {
//			System.out.println(eachElement.getText());
//            eachElement.click();
                
//        }
        
//Dropdown Selection by xPATH
//        wd.get("https://www.globalsqa.com/demo-site/select-dropdown-menu/");
//        WebElement we=wd.findElement(By.tagName("select"));
//        Select sel=new Select(we);
//        sel.selectByIndex(2);
//        sel.selectByValue("ARM");
//        sel.selectByVisibleText("Bahamas");
        
        
 //Table Data by Xpath---NEED to do
//
//    	System.setProperty("webdriver.chrome.driver","C:\\Users\\03800E744\\eclipse-workspace\\Reskill\\chromedriver.exe");
//    	WebDriver wd=new ChromeDriver();
//            	wd.get("https://www.techlistic.com/p/demo-selenium-practice.html");
//    	Thread.sleep(10000);
//    	wd.manage().window().maximize();
//    	
//        List<WebElement> weColData=wd.findElements(By.xpath("//table[@id='customers']//tr//td[2]"));
//     	for(int i=0;i<weColData.size();i++) 
//     	{
//       	       	System.out.println(weColData.get(i).getText());
//    	}
  
////WAIT        
      
      //Implicit
      	//	wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
      		//PageTimeout
      		//wd.manage().timeouts().pageLoadTimeout(10, null);
      //Explicit
        
        //WebDriverWait waitExp=new WebDriverWait(wd, 5);
		
    	//waitExp.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("ABC")));
     //Fluent Wait
    	//Wait<WebDriver> waitFluent=new FluentWait<WebDriver>(wd)
    		//	.withTimeout(10, TimeUnit.SECONDS)
    		//	.pollingEvery(2,TimeUnit.SECONDS)
    		//	.ignoring(NoSuchElementException.class);
    	//waitFluent.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("ABC")));

    	
    	
    	
 //Handling Tabs
    	
//     	System.setProperty("webdriver.chrome.driver","C:\\Users\\03800E744\\eclipse-workspace\\Reskill\\chromedriver.exe");
//    	WebDriver wd=new ChromeDriver();
		//Navigating to google
//         wd.get("https://www.google.com/");
//       wd.manage().window().maximize();
//       Thread.sleep(5000);
//         wd.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL+ "t");
////       String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,Keys.RETURN);
////       wd.findElement(By.linkText("https://demos.jquerymobile.com/1.4.5/checkboxradio-radio/")).sendKeys(selectLinkOpeninNewTab);
//         
//         wd.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
//         ArrayList<String> tabs = new ArrayList<String> (wd.getWindowHandles());
//         wd.switchTo().window(tabs.get(0));
         
//Set<String> tabs=wd.getWindowHandles();
//for(String eachTab:tabs)
//{
//       	System.out.println(eachTab);
//       	wd.switchTo().window(eachTab);
//       	}

         
//         ((JavascriptExecutor) wd).executeScript("window.open('https://www.google.com/')");
//         wd.manage().window().maximize();
//         Thread.sleep(10000);
//         ((JavascriptExecutor) wd).executeScript("window.open('https://www.techlistic.com/p/demo-selenium-practice.html')");
//         
//       wd.close();
//       System.out.println("closed");
//}
//}


//////////////////////////ALERTS

//    	http://demo.automationtesting.in/Alerts.html

      			// Launching Chrome
//    				System.setProperty("webdriver.chrome.driver","C:\\Users\\03800E744\\eclipse-workspace\\Reskill\\chromedriver.exe");
//    				WebDriver wd = new ChromeDriver();
//    				// Navigating to demo alerts
//    				wd.get("http://demo.automationtesting.in/Alerts.html");
//    				Thread.sleep(5000);
//    				wd.findElement(By.xpath("//*[@class='btn btn-danger']")).click();
//    				wd.switchTo().alert().accept();
//    				Thread.sleep(5000);
//    				wd.findElement(By.partialLinkText("Alert with OK & Cancel")).click();
//    				wd.findElement(By.xpath("//*[@class='btn btn-primary']")).click();
//    				wd.switchTo().alert().accept();
//    				wd.findElement(By.xpath("//*[@class='btn btn-primary']")).click();
//    				wd.switchTo().alert().dismiss();
//    				Thread.sleep(5000);
//    				wd.findElement(By.partialLinkText("Alert with Textbox")).click();
//    				wd.findElement(By.xpath("//*[@class='btn btn-info']")).click();
//    				wd.switchTo().alert().sendKeys("test");
//    				wd.switchTo().alert().accept();
//    				wd.findElement(By.xpath("//*[@class='btn btn-info']")).click();
//    				wd.switchTo().alert().accept();
//    				
//    				wd.close();

////////////////////////IFRAME
    				
//    				// Launching Chrome
//    				System.setProperty("webdriver.chrome.driver","C:\\Users\\03800E744\\eclipse-workspace\\Reskill\\chromedriver.exe");
//    				WebDriver wd = new ChromeDriver();
//    				// Navigating to website
//    				wd.get("https://www.globalsqa.com/demo-site/frames-and-windows/#iFrame");
//    				Thread.sleep(5000);
//    				wd.switchTo().frame("globalSqa");
//    				//wd.switchTo().frame(3);
//    				wd.findElement(By.partialLinkText("Home")).click();
//    				Thread.sleep(5000);
//    				wd.close();
//    
//    };
// };
    

 ////////////////////JAVA SCRIPT EXECUTOR
 
	// Launching Chrome
//	System.setProperty("webdriver.chrome.driver","C:\\Users\\03800E744\\eclipse-workspace\\Reskill\\chromedriver.exe");
//	WebDriver wd = new ChromeDriver();
//	wd.manage().window().maximize();
//	wd.get("https://www.google.com/");
//	wd.findElement(By.name("q")).sendKeys("Selenium is Good"+Keys.ENTER);
//	Thread.sleep(5000);
//	JavascriptExecutor executor = (JavascriptExecutor)wd;
//	executor.executeScript("window.scrollBy(0,1000)");
//	Thread.sleep(5000);
//	
//	WebElement element = wd.findElement(By.partialLinkText("Selenium in diet: MedlinePlus Medical Encyclopedia"));
//	executor.executeScript("arguments[0].click();", element);
//	wd.close();
//    }
//}


////////////////////////////////////ACTION CLASS

// Launching Chrome
System.setProperty("webdriver.chrome.driver","C:\\Users\\03800E744\\eclipse-workspace\\Reskill\\chromedriver.exe");
WebDriver wd = new ChromeDriver();
wd.manage().window().maximize();
wd.get("https://www.google.com/");
wd.findElement(By.name("q")).sendKeys("Selenium is Good"+Keys.ENTER);
Thread.sleep(5000);
WebElement inputSerachBox = wd.findElement(By.name("q"));
Actions action=new  Actions(wd);
action.keyDown(inputSerachBox,Keys.SHIFT);
action.sendKeys(inputSerachBox,"selenium");
action.keyUp(inputSerachBox,Keys.SHIFT);
action.build().perform();
Thread.sleep(10000);

//Double click
//action.doubleClick(inputSerachBox);
//action.sendKeys(inputSerachBox,"CONTROL"+'T');
//CTRL+C

Robot rbt;
try
{
	rbt=new Robot();
	rbt.keyPress(KeyEvent.VK_6);
			
}catch(AWTException e)

{

e.printStackTrace();
}
wd.close();
    }
}    



///////////////////////////
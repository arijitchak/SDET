package Day4TESTNG;
import org.testng.annotations.Test;

public class TestNG_2 {
	@Test(dependsOnMethods="testMethod_2")
	public void testMethod_1() {
		System.out.println("Inside my test ng method testmethod_1");
	}

@Test()
public void testMethod_2() {
	System.out.println("Inside my test ng method testmethod_2");
}
}

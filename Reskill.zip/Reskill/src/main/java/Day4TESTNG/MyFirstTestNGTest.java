
//JUNIT
//
//TestNG  (Test Next Generation)
//https://marketplace.eclipse.org/content/testng-eclipse?mpc=true&mpc_state=
//
//https://testng.org/testng-eclipse-update-site
//
//
//@AnnotationNAme
//
//@BeforeSuite-Before All test in suite(1st)
//@AfterSuite-After All test in suite(end)
//@BeforeTest-will run before any test method belonging to the classes
//@AfterTest-will run Afte all test method belonging to the classes have run
//@BeforeClass-Before All test in class(1st)
//@AfterClass-After All test in class(end)
//@BeforeMethod-Before each test 
//@AfterMethod-After each test 
//@Test
//
//BeforeSuite
//    BeforeTest
//        BeforeClass 
//            Before method
//                TEST
//            AfterMethod
//        AfterClass
//    AfterTest
//AfterSuite
//


package Day4TESTNG;
import org.testng.annotations.Test;

public class MyFirstTestNGTest {
	@Test
	public void firstTestngMethod() {
		System.out.println("Hello TestNG");
	}
}
package runner;
//import org.junit.Runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


@org.junit.runner.RunWith(Cucumber.class)
@CucumberOptions(features = "./src/main/resources/Cucumber", glue = { "stepDefinition" },tags="@searchscenario")

public class Runner_Cucumber {

}


package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.core.cli.Main;

public class GoogleSearch

{
	WebDriver wd=null;
	
	@Given("I want to launch Browser")
	public void i_want_to_launch_google_com() {
	    
		System.setProperty("webdriver.chrome.driver","C:\\Users\\03800E744\\eclipse-workspace\\Reskill\\chromedriver.exe");
		wd = new ChromeDriver();				
		wd.manage().window().maximize();
		
	}

	@And("I type google.com")
	public void typing_selenium() {
		
		wd.get("https://www.google.com/");
		wd.findElement(By.name("q")).sendKeys("seleinum is good"+Keys.ENTER);
	}
   @Then("Click on First Link")
   public void click_first_link() {

    wd.findElement(By.xpath("//h3[contains(text(),'7 Science-Based Health Benefits of Selenium - Heal')]")).click();
    wd.close();

    }
  
   
}

package Reskill;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
    	//launching Chrome
    	System.setProperty("webdriver.chrome.driver","C:\\Users\\03800E744\\eclipse-workspace\\Reskill\\chromedriver.exe");
    	WebDriver wd=new ChromeDriver();
		//Navigating to google
		wd.get("https://www.google.com/");
		Thread.sleep(5000);
		System.out.println("Success");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		//Extracting Navigated URL
		System.out.println(wd.getCurrentUrl());
		//Extracting Title
		System.out.println("TITLE:"+ wd.getTitle());
		//Closing Chrome
		//wd.close();
		//wd.navigate().to("http://yahoo.com/");
		//wd.navigate().back();
		//wd.navigate().refresh();
		wd.findElement(By.name("q")).sendKeys("seleinum is good"+Keys.ENTER);
	    wd.findElement(By.xpath("//h3[contains(text(),'7 Science-Based Health Benefits of Selenium - Heal')]")).click();
	    wd.close();
		
		
		
		   	       
        
    }
}
